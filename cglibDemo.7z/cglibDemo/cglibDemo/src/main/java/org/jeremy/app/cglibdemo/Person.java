package org.jeremy.app.cglibdemo;

import java.io.Serializable;

public class Person implements Serializable{

	/**
	 * 
	 */
	private static final long serialVersionUID = 7744598849779531304L;

	public void say() {
		System.out.println("hello");
	}
	
}
